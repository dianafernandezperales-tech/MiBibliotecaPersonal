package com.mibibliotecapersonal.app
data class Book(val id:String,val title:String,val author:String,val summary:String="",val coverUrl:String="",var status:Status=Status.WISHLIST,var startedAt:Long?=null,var finishedAt:Long?=null,var currentPage:Int=0,var totalPages:Int=0,var rating:Float=0f)
enum class Status { WISHLIST,PENDING,READING,READ }
