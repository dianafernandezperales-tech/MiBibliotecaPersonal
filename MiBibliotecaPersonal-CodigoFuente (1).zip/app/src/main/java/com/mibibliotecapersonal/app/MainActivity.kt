package com.mibibliotecapersonal.app
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
class MainActivity:AppCompatActivity(){
 private lateinit var store:BookStore; private val books=mutableListOf<Book>(); private lateinit var content:LinearLayout
 private val cream by lazy{getColor(R.color.cream)};private val green by lazy{getColor(R.color.green)};private val dark by lazy{getColor(R.color.dark_green)}
 override fun onCreate(b:Bundle?){super.onCreate(b);store=BookStore(this);books.addAll(store.all());showHome()}
 private fun base(t:String):LinearLayout{val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setBackgroundColor(cream)
  val h=TextView(this);h.text=t;h.textSize=26f;h.setTextColor(dark);h.setTypeface(h.typeface,1);h.setPadding(24,22,18,12);r.addView(h)
  content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.setPadding(18,4,18,18);val s=ScrollView(this);s.addView(content);r.addView(s,LinearLayout.LayoutParams(-1,0,1f));r.addView(nav());return r}
 private fun nav():View{val b=LinearLayout(this);b.orientation=LinearLayout.HORIZONTAL;listOf("Inicio","Biblioteca","Lectura","Leídos","Deseos","Recomendaciones","Resumen").forEach{l->val v=TextView(this);v.text=l;v.textSize=10f;v.gravity=Gravity.CENTER;v.setPadding(3,8,3,8);v.setOnClickListener{when(l){"Inicio"->showHome();"Biblioteca"->showList(Status.PENDING,"Biblioteca");"Lectura"->showList(Status.READING,"Lectura actual");"Leídos"->showList(Status.READ,"Leídos");"Deseos"->showWishlist();"Recomendaciones"->showRecommendations();"Resumen"->showSummary()}};b.addView(v,LinearLayout.LayoutParams(0,-2,1f))};return b}
 private fun showHome(){val r=base("Mi Biblioteca Personal");content.addView(card("Tu espacio para descubrir, leer y recordar historias."));listOf("📚 Pendientes" to Status.PENDING,"📖 Lectura actual" to Status.READING,"✅ Leídos" to Status.READ,"❤️ Deseos" to Status.WISHLIST).forEach{content.addView(card("${it.first}\n${books.count{b->b.status==it.second}} libros"))};setContentView(r)}
 private fun showList(s:Status,t:String){val r=base(t);books.filter{it.status==s}.forEach{addCard(it)};if(content.childCount==0)content.addView(card("Todavía no hay libros aquí."));setContentView(r)}
 private fun addCard(book:Book){val c=MaterialCardView(this);c.radius=20f;c.setContentPadding(16,14,16,14);val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
  val a=TextView(this);a.text=book.title;a.textSize=18f;a.setTextColor(dark);a.setTypeface(a.typeface,1);box.addView(a);val au=TextView(this);au.text=book.author;au.setTextColor(green);box.addView(au);box.addView(TextView(this).apply{text=if(book.summary.isBlank())"Sin resumen disponible todavía." else book.summary.take(150);setTextColor(getColor(R.color.muted));setPadding(0,6,0,6)})
  if(book.status==Status.READING){val pct=if(book.totalPages>0)(book.currentPage*100/book.totalPages).coerceIn(0,100)else 0;box.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{progress=pct;max=100});box.addView(TextView(this).apply{text="$pct% · ${book.currentPage}/${book.totalPages} páginas"});box.addView(MaterialButton(this).apply{text="Actualizar progreso";setOnClickListener{progress(book)}});box.addView(MaterialButton(this).apply{text="Terminar libro";setOnClickListener{finish(book)}})}
  if(book.status==Status.PENDING)box.addView(MaterialButton(this).apply{text="Empezar a leer";setOnClickListener{book.status=Status.READING;book.startedAt=System.currentTimeMillis();save();showList(Status.PENDING,"Biblioteca")}})
  c.addView(box);c.setOnClickListener{detail(book)};content.addView(c,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,12)})}
 private fun detail(b:Book){val m=buildString{append(b.title).append("\n\n").append(b.author).append("\n\n").append(if(b.summary.isBlank())"Resumen no disponible." else b.summary);if(b.status==Status.READ)append("\n\n⭐ ").append(b.rating).append("\nInicio: ").append(date(b.startedAt)).append("\nFinal: ").append(date(b.finishedAt))};AlertDialog.Builder(this).setTitle("Ficha del libro").setMessage(m).setPositiveButton("Cerrar",null).setNegativeButton("Eliminar"){_,_->AlertDialog.Builder(this).setTitle("¿Seguro que quieres borrarlo?").setNegativeButton("Cancelar",null).setPositiveButton("Borrar"){_,_->books.remove(b);save();showHome()}.show()}.show()}
 private fun progress(b:Book){val e=EditText(this);e.inputType=2;e.setText(b.currentPage.toString());AlertDialog.Builder(this).setTitle("Actualizar progreso").setView(e).setPositiveButton("Guardar"){_,_->b.currentPage=e.text.toString().toIntOrNull()?:b.currentPage;save();showList(Status.READING,"Lectura actual")}.setNegativeButton("Cancelar",null).show()}
 private fun finish(b:Book){b.status=Status.READ;b.finishedAt=System.currentTimeMillis();AlertDialog.Builder(this).setTitle("¿Qué valoración le das?").setSingleChoiceItems(arrayOf("⭐","⭐⭐","⭐⭐⭐","⭐⭐⭐⭐","⭐⭐⭐⭐⭐"),-1){d,w->b.rating=(w+1).toFloat();save();d.dismiss();showList(Status.READ,"Leídos")}.show()}
 private fun showWishlist(){val r=base("Deseos");val e=EditText(this);e.hint="🔎 ¿Qué libro estás buscando?";content.addView(e);val res=LinearLayout(this);res.orientation=LinearLayout.VERTICAL;content.addView(res);books.filter{it.status==Status.WISHLIST}.forEach{wishButton(res,it,true)};e.addTextChangedListener(object:android.text.TextWatcher{override fun afterTextChanged(s:android.text.Editable?){if((s?.length?:0)<2)return;lifecycleScope.launch{OpenLibrary.search(s.toString()).forEach{b->wishButton(res,b,false)}}};override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}});setContentView(r)}
 private fun wishButton(p:LinearLayout,b:Book,existing:Boolean){val x=MaterialButton(this);x.text=if(existing)"❤️ ${b.title} — ${b.author}" else "＋ ${b.title} — ${b.author}";x.setOnClickListener{if(existing)b.status=Status.PENDING else {books.removeAll{it.id==b.id};books+=b};save();showWishlist()};p.addView(x)}
 private fun showRecommendations(){val r=base("Recomendaciones");content.addView(card("💡 Para ti\n\nRecomendaciones basadas en tus lecturas y valoraciones."));books.filter{it.status==Status.READ}.sortedByDescending{it.rating}.take(3).forEach{content.addView(card("❤️ Porque te gustó ${it.title}\nBusca más libros del mismo autor o género."))};setContentView(r)}
 private fun showSummary(){val r=base("Resumen anual");val y=Calendar.getInstance().get(Calendar.YEAR);val read=books.filter{it.status==Status.READ&&it.finishedAt?.let{t->Calendar.getInstance().apply{timeInMillis=t}.get(Calendar.YEAR)==y}==true};content.addView(card("🎬 Tu año en historias $y\n\n📚 Libros leídos: ${read.size}\n⭐ Mejor valoración: ${read.maxOfOrNull{it.rating}?:0}\n✍️ Autor/a más leído/a: ${read.groupingBy{it.author}.eachCount().maxByOrNull{it.value}?.key?:"—"}"));setContentView(r)}
 private fun card(s:String)=TextView(this).apply{text=s;textSize=17f;setTextColor(dark);setPadding(18,20,18,20);background=getDrawable(R.drawable.bg_card)}
 private fun save()=store.save(books);private fun date(m:Long?)=m?.let{SimpleDateFormat("d 'de' MMMM 'de' yyyy",Locale("es")).format(Date(it))}?:"—"
}
