package com.mibibliotecapersonal.app
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
object OpenLibrary{
 private val client=OkHttpClient()
 suspend fun search(q:String):List<Book>=withContext(Dispatchers.IO){
  if(q.isBlank())return@withContext emptyList()
  val url="https://openlibrary.org/search.json?q=${URLEncoder.encode(q,"UTF-8")}&limit=12"
  val body=client.newCall(Request.Builder().url(url).build()).execute().body?.string()?:return@withContext emptyList()
  val docs=JSONObject(body).optJSONArray("docs")?:return@withContext emptyList()
  buildList{for(i in 0 until minOf(12,docs.length())){val d=docs.getJSONObject(i);val id=d.optString("key");val t=d.optString("title");val a=d.optJSONArray("author_name")?.optString(0)?:"Autor desconocido";val c=d.optInt("cover_i",0).takeIf{it!=0}?.let{"https://covers.openlibrary.org/b/id/${it}-M.jpg"}?:"";if(t.isNotBlank())add(Book(id,t,a,coverUrl=c))}}
 }
}
