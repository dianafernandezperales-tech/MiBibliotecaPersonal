package com.mibibliotecapersonal.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
class BookStore(context:Context){
 private val p=context.getSharedPreferences("books",Context.MODE_PRIVATE)
 fun all():MutableList<Book>{
  val a=JSONArray(p.getString("items","[]")); val r=mutableListOf<Book>()
  for(i in 0 until a.length()){val o=a.getJSONObject(i);r+=Book(o.getString("id"),o.getString("title"),o.getString("author"),o.optString("summary"),o.optString("coverUrl"),Status.valueOf(o.optString("status","WISHLIST")),if(o.isNull("startedAt"))null else o.optLong("startedAt"),if(o.isNull("finishedAt"))null else o.optLong("finishedAt"),o.optInt("currentPage"),o.optInt("totalPages"),o.optDouble("rating").toFloat())}
  return r
 }
 fun save(bs:List<Book>){val a=JSONArray();bs.forEach{b->a.put(JSONObject().apply{put("id",b.id);put("title",b.title);put("author",b.author);put("summary",b.summary);put("coverUrl",b.coverUrl);put("status",b.status.name);put("startedAt",b.startedAt?:JSONObject.NULL);put("finishedAt",b.finishedAt?:JSONObject.NULL);put("currentPage",b.currentPage);put("totalPages",b.totalPages);put("rating",b.rating)})};p.edit().putString("items",a.toString()).apply()}
}
