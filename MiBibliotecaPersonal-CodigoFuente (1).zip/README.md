# Mi Biblioteca Personal
Código fuente Android/Kotlin. Incluye workflow de GitHub Actions para generar `app-debug.apk`.
