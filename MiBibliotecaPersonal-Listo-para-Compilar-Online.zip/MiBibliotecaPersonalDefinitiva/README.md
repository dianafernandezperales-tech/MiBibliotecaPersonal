# Mi Biblioteca Personal — proyecto Android

Este proyecto está preparado para compilarse **online con GitHub Actions**, sin instalar Android Studio ni activar Linux en el Chromebook.

## Qué hace el proyecto

- Biblioteca / Pendientes
- Lectura actual
- Leídos
- Deseos
- Búsqueda de libros mediante Open Library
- Recomendaciones iniciales
- Resumen anual
- Perfil con nombre editable
- Valoraciones de 1 a 5 estrellas
- Fechas de inicio y finalización
- Progreso por página
- Confirmación antes de eliminar
- Guardado local de los datos

## Cómo se obtiene el APK

El repositorio incluye `.github/workflows/build-apk.yml`. GitHub Actions instala Java 17 y Gradle 8.10.2, prepara el Android SDK y ejecuta `gradle :app:assembleDebug`. El APK se guarda como un **artifact** llamado `MiBibliotecaPersonal-APK`.

> Esta compilación genera un APK de depuración para probar la aplicación. Antes de distribuirla públicamente habrá que generar una versión firmada de lanzamiento.
